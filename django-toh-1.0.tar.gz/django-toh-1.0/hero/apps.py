from django.apps import AppConfig


class HeroConfig(AppConfig):
    name = 'hero'
