from django.conf.urls import url, include
from .views import heroList, heroDetail


urlpatterns = [
    url(r'^(?P<hero_id>[0-9]+)$', heroDetail, name='heroDetail'),
    url(r'^$', heroList, name='heroList'),
]

