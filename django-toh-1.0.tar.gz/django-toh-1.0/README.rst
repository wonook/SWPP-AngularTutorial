==============
Tour of Heroes
==============

Sample Django app for the angular tutorial.

Quick start
-----------

1. Add "hero" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'hero',
    ]

2. Include the hero URLconf in your project urls.py like this::

    url(r'^api/hero/', include('hero.urls')),

3. Run `python manage.py migrate` to create the hero models.

4. Start the development server and visit http://localhost:8000/api/hero/.
